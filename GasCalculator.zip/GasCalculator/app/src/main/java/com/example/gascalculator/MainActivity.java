package com.example.gascalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    private final static String TAG = "MainActivity";


    private EditText mNumGallonsText;

    private TextView mTotalSaleTextView;

    private RadioGroup mGradeRadioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mNumGallonsText = findViewById(R.id.num_gallons_edit_text);
        mTotalSaleTextView = findViewById(R.id.total_sale_text_view);
        mGradeRadioGroup = findViewById(R.id.grade_radio_group);

        Log.d(TAG, "onCreate was called");



    }

    //This method is called when the calculate button is clicked
    //This method is mapped to the calculate button ina activity.xml android onClick="calculateClick

    // this method is called when the calculate button is clicked
    //this method is mapped to the calculate button in activity_main.xml android:onClick="calculateClick

    public void calculateClick(View view) {
        String numGallonsStr = mNumGallonsText.getText().toString();

        int loopTracker = 0;
        int numGallons;
        do {

            //prevent application from crashing if invalid input
            try {
                numGallons = Integer.parseInt(numGallonsStr);
                loopTracker = 1;

            } catch (NumberFormatException ex) {
                numGallons = 0;
                System.out.println("Please try again and insert a number");
                Toast.makeText(this, R.string.pleaseTryAgain, Toast.LENGTH_LONG).show();
            }
        } while (loopTracker == 0);

        Log.d(TAG, "number is " + numGallonsStr);

        //determine the cost per fuel grade

        double perGallon = 0.0;
        int checkedGrade = mGradeRadioGroup.getCheckedRadioButtonId();
        if (checkedGrade == R.id.regular_radio_button) {
            perGallon = 3.68;
        } else if (checkedGrade == R.id.medium_radio_button) {
            perGallon = 4.07;
        } else if (checkedGrade == R.id.premium_radio_button) {
            perGallon = 4.39;
        }

        double totalSale = (double) numGallons * perGallon;

        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        String ttlSale = decimalFormat.format(totalSale);

        mTotalSaleTextView.setText("Total Sale: " + ttlSale);
    }
}